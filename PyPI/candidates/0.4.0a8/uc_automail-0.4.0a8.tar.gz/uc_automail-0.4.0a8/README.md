# UC_AutoMaiL

[English overview](README.en.md)

UC_AutoMaiL（旧DIY AutoML）は、機械学習モデルを比較し、評価値の不確かさを調べるPythonパッケージです。名前の `UC` は開発の出発点である不確かさ（Uncertainty）に由来します。配布名とCLIは `uc-automail` です。 [α版の試用手順](docs/PYPI_ALPHA_TRIAL.md)

旧クラウド環境の0.4.0a1ソースは未取得です。このリポジトリは元資料ZIPと引継ぎ仕様から新たに実装しました。初回再実装は **0.4.0a1.post1**、DL反復は **0.4.0a2**、UL部分抽出は **0.4.0a3**、SL設定探索は **0.4.0a4**、図付きExcelは **0.4.0a5**、評価値の誤差評価は **0.4.0a6**、DLバックエンド追加の準備は **0.4.0a7**、分類・状態推定・GCNを収めた配布試用版は **0.4.0a8** です。旧実装とのAPI・数値・manifest互換性は保証していません。schema番号2/3/4は引継ぎの用途区分を採用したもので、旧validatorとの互換を意味しません。過去の96 passedは今回の検証結果ではありません。

Python 3.12、数値特徴量・欠損なし・分類ラベル付きCSVが対象です。ULも外部診断のためtarget列が必要です。元資料は `originals/` に変更せず保存しています。

Pythonパッケージの自作コードと配布用ファイルはMITライセンスです。同梱サンプルの出典・利用条件はデータごとの記録を参照してください。 [ライセンスと適用範囲](LICENSE) · [サンプルデータの出典と利用条件](data/reference/README.md)

主目的は、MLの結果に誤差評価を含め、データ量・品質・学習の不安定さについて議論できる材料を残すことです。現状は固定モデルに条件付きのtest区間と一部の反復を実装しています。データ量に対する学習曲線、再学習・選定をやり直す変動、グループ/時間の評価は今後で、区間幅だけから量不足や品質不良を自動判定する機能ではありません。目的と優先順は `docs/UNCERTAINTY_DESIGN.md` に記録しています。

0.4.0a6の`uncertainty`は保存済みSL/DLの4指標とクラス別指標へbootstrap SE・percentile区間を付け、図付きExcelを別出力します。クラス件数固定/通常の2方式を選べます。元の学習結果は変更せず、学習・選定のやり直しや系統誤差まで評価した意味ではありません。使い方は[評価値の誤差評価](docs/METRIC_UNCERTAINTY_GUIDE.md)です。

定量化した指標を用途に合うモデル選定へつなぎ、DS以外にも拾えた件数・見逃し・誤案内と限界を説明できる構成を目指します。費用・確率校正・閾値の最適化と、一般利用者への伝わり方の検証は未実施です。

学習前に `audit-data` で欠損・重複・クラス件数と評価条件を点検できます。`select` とBP画面では、顧客などのグループで分ける評価と、過去で学習して後の期間で評価する日付順の分割を選べます。 [点検と評価の手順](docs/DATA_AUDIT.md) · [ロードマップ](docs/ROADMAP.md)

開発作業の再開・引継ぎは、[最新の状態と引継ぎ方針](docs/HANDOFF.md)を入口にしてください。

## Full Paper

2026年11月19日・技術論文の改訂稿。データ点検からDS・BP向け出力までの運用フロー、分類評価の実装と実験、再実行の手順をまとめました。 [PDF](docs/papers/DIY_AutoML_Full_Paper_20261119/DIY_AutoML_Full_Paper_20261119.pdf) · [TeXプロジェクト](docs/papers/DIY_AutoML_Full_Paper_20261119/README.md) · [復元用ZIP](docs/papers/DIY_AutoML_Full_Paper_20261119/DIY_AutoML_Full_Paper_20261119_TeX.zip)

## 技術短報

- 2026年11月9日・試読版。評価基盤の方法と、ホテル予約、カフェ券、再購入の3例を収録。 [試読版PDF](docs/letters/DIY_AutoML_Letter_20261109.pdf)
- 2026年11月19日・改稿案。グループ分割、日付順評価、曜日・時間帯の多数決との比較を追加。 [改稿案PDF](docs/letters/DIY_AutoML_Letter_20261119_review.pdf)

## セットアップ

配布候補の **0.4.0a8** は、wheelからWindowsとColabで分類・カルマン・粒子フィルタ・GCNを試せるα版です。 [試用手順とノートブック](docs/PYPI_ALPHA_TRIAL.md)

0.4.0a7は、PyTorch追加に向けた共通データ/結果形式とTensorFlow学習処理の分離です。現在の学習バックエンドはTensorFlowのみで、PyTorch/JAXの実装や依存追加はまだありません。Julia/Rust版も将来展望です。[準備した境界と次の条件](docs/DL_BACKENDS.md)を参照してください。

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-local.lock.txt
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python -m pip check
.venv/bin/python -m pytest -q
```

ロックは今回のPython 3.12/Linux CPU環境のものです。旧環境のロックを復元したものではありません。TensorFlowを使わない場合は `pip install -e .` でコアのみ導入できます。DL用の追加依存は `pip install -e '.[dl]'` です。

## 実行

初めて使うCSVは、先に `audit-data` で点検できます。学習なしで、確認すべき項目をExcelとJSONに保存します。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m diy_automl audit-data --csv data/reference/raisin.csv --target target --row-unit "レーズン1粒" --output runs/raisin-data-audit
```

元CSVを保管し、繰り返し使う中継データには `--convert parquet` で作る圧縮Parquetを優先します。DBファイルが必要なときは `--convert duckdb` を指定できます。 [変換と直接読み出しの手順](docs/DATA_AUDIT.md#parquetとduckdbへの変換)

`extract-data` で中継ファイルから列・条件・件数を指定し、学習用CSVを作れます。ビジネス向けの点検・圧縮には、日本語の要約を出す `prepare-bp --compress` を使えます。 [抽出の手順](docs/DATA_AUDIT.md#学習用csvを抽出する) · [ビジネス向けの手順](docs/DATA_AUDIT.md#ビジネス向けの点検と圧縮)

Windowsでは `bp-preview` でCSVの点検、使う列の抽出と再点検、主要5モデルのCPU比較まで実行できます。保留テストの正解・誤分類とラベル別の見逃し・誤検知を画面で確認し、モデル比較表と評価区間をExcelで開けます。 [画面の起動と使い方](docs/DATA_AUDIT.md#データ点検の画面を使う)

```sh
.venv/bin/python -m diy_automl run --csv data/reference/wine.csv --target target --output runs/wine
.venv/bin/python -m diy_automl select --csv data/reference/wine.csv --target target --output runs/wine-select
.venv/bin/python -m diy_automl repeat-ul --csv data/reference/wine.csv --target target --seeds 42 43 44 --output runs/wine-repeat
.venv/bin/python scripts/validate_selection_run.py runs/wine-select
```

出力フォルダは新規のみ使用し、既存出力を上書きしません。Excel、配列NPZ、入力・ソース・出力ハッシュ付きmanifestを保存します。失敗時はmanifestをfailedにします。UL反復では完了・失敗・未実行を記録し、部分結果も保存します。

`run` は探索的比較です。SL5モデル、UL54候補、DL単一MLPを実行します。`--methods sl ul` でDLを省略できます。SLはtestをモデル選定に使いません。モデル選定が目的なら `select` を使用してください。

`select` は学習側の共通層化5foldのmacro F1平均で選定し、選定した1モデルだけtest評価します。数値同率はatol=1e-12、rtol=0で残し、候補順を採用します。testスコア・時間では解消しません。層化paired percentile bootstrapは正解クラス別件数を固定した1,000反復、95%、seed=43が既定です。固定済みモデル・観測クラス件数に条件付きであり、学習・選定の変動を含みません。ゼロ幅も未知の不確かさゼロを意味しません。

### 木の深さを設定する

`--tree-max-depth` は決定木とランダムフォレストの各木の深さに、指定した正の整数を上限として適用します。指定値はExcelの `Summary` と `manifest.json` に保存されます。深さ3でRaisinを比較する例です。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m diy_automl select --csv data/reference/raisin.csv --target target --tree-max-depth 3 --output runs/raisin-depth-3
```

`run --methods sl`、`select`、`rank-sl`、`tune` で指定できます。`annealing-check` では `--model "Decision Tree"` または `--model "Random Forest"` と組み合わせます。Python APIの引数は `tree_max_depth=3` です。`tune` で指定すると木の深さを固定し、ほかの設定を比較します。 [探索範囲の詳細](docs/SL_TUNING_GUIDE.md#宣言した探索範囲と順序)

手法別に指定するには `--decision-tree-max-depth` と `--random-forest-max-depth` を使います。共通の上限と併用した場合は、各モデルの個別指定が優先されます。次の例は決定木だけに上限3を指定します。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m diy_automl select --csv data/reference/raisin.csv --target target --decision-tree-max-depth 3 --output runs/raisin-decision-tree-3
```

Pythonでは `tree_max_depths={"Decision Tree": 3, "Random Forest": 5}` のように渡します。`annealing-check` の個別指定は `--model` で選んだ手法に適用します。使用した個別指定は `Summary` とmanifestから確認できます。

### 教師あり学習のCPU並列度を指定する

DS向けCLIとPython APIでは、対応するBLAS/OpenMPのスレッド上限と、ランダムフォレストの並列数を個別に設定できます。たとえば `select` に `--cpu-threads 2 --forest-jobs 2` を渡します。Pythonでは `cpu_threads=2, forest_jobs=2` を指定します。設定は `Summary` とmanifestに記録します。

`--cpu-threads` は教師あり学習・予測中のネイティブスレッドプールの上限です。`--forest-jobs -1` はjoblibが認識する全CPUを使います。二つは異なる層の並列設定なので、CPUやメモリに合わせて調整します。`run` の教師あり学習、`select`、`rank-sl`、`tune`、`annealing-check` に対応します。`annealing-check` で並列数を指定する場合は `--model "Random Forest"` を選びます。 [scikit-learnの並列処理の説明](https://scikit-learn.org/stable/computing/parallelism.html) · [BP画面のCPU設定](docs/DATA_AUDIT.md#画面からのモデル比較)

`select` と `tune` の `--progress both` は、進捗を標準エラー出力に表示し、`progress.jsonl` と評価Excelの `Progress` シートにも残します。 [表示と保存の設定](docs/SL_TUNING_GUIDE.md#select-と-tune-の途中経過を残す)

DLはtrainだけでscalerをfitします。`--split-seed` と `--training-seed` を独立に指定でき、省略時は両方とも `--seed`（42）を使います。分割は概ね64/16/20、MLP32-16-8、100epoch、batch16です。test最高のseedを選ぶ入口はありません。

ULは固定データ最大5,000行、KMeans n_init=auto、GMM n_init=1/full、階層4linkage、k=2..10です。UL反復のTarget ARIとAssignment ARIは別の量です。45 seed対を独立標本としたSEM/CIや自動選定は行いません。fold SD、点ごとのSilhouette SD/SE、seed SD、test区間も区別します。

`notebooks/Local_Comparison.ipynb` は共通関数を呼ぶ5シートと図5枚のローカル入口です。図付きExcelは共通のreport関数で別ファイルへ出力します。Notebookのscikit-learn由来の3データセットは開発用です。SL/DLとULを総合順位にしません。

小麦の品種分類（Seeds）とレーズンの品種分類（Raisin）も、数値7列のCSVで試せます。 [データの出典・ライセンスとCPU実行例](data/reference/README.md)

復旧範囲と検証結果は `docs/RESET_HANDOFF.md` と `docs/VALIDATION_UL_REPEAT.md` を参照してください。2026年11月8日（日本時間）、利用者の依頼により再実装した成果物を **main** へ反映しました。通常の取得・参照先はmainです。`recovery/reimplemented-0.4.0a1-post1` は移行前の履歴を保管するブランチとして残しています。

Notebookを使う場合は、必要に応じて `.venv/bin/python -m pip install ipykernel` を追加し、エディタでこの.venvをカーネルに指定してください。0.4.0a5では専用カーネルで全コードセルを実行し、100epochのDLを含む数値出力・外部PNG5枚・8枚を埋め込んだExcel生成まで確認しました。手順はdocs/NOTEBOOK_GUIDE.md、任意のNotebook実行ツールのロックはrequirements-notebook.lock.txtです。

Gitからの再開手順と、ローカルコミット・pushの確認方法は `docs/COMMIT_GUIDE.md` に記載しています。

## 教師あり5モデルの繰り返し比較

`rank-sl` は、固定の5モデルを学習側の共通層化5分割で繰り返し比較します。既定は5反復、主指標はmacro F1です。モデルのseedを固定し、各反復のfold平均、全反復の平均による点順位、順位の範囲、1位になった反復数を記録します。1位タイは該当モデルをすべて数えます。foldや反復のスコアには依存があるため、反復間のSDは分割に対する変動の記述に使います。

```powershell
.\.venv\Scripts\python.exe -m diy_automl rank-sl --csv data/reference/wine.csv --target target --output runs/wine-ranking
.\.venv\Scripts\python.exe scripts/validate_sl_ranking.py runs/wine-ranking
```

出力は `report.xlsx`（先頭の `CV_Ranking` に順位表）、分割と全候補のfold外予測を記録した `arrays.npz`、設定とハッシュを記録した `manifest.json` です。最初に約20%を最終テストとして確保し、CVで選んだ1モデルだけを評価します。混同行列は `Test_Confusion`、クラス別のPrecision・Recall・F1と件数は `Test_By_Class` で確認できます。Python APIは `diy_automl.rank_sl_csv` です。

`--comparison-fraction 0.25` を付けると、最終テストを除いた残りの25%を比較用に確保します。比較用の同じ行に対する各モデルとCV首位の差を、正解クラス別件数を固定したpaired bootstrapで評価し、順位表と `Comparison_Differences` に記録します。差の区間が0を含む場合は優劣を保留します。区間は独立した評価行、学習済みモデル、観測クラス件数を前提とし、モデルごとの比較として読みます。最終テストの対象はCVの結果で決めます。

同じ分割をAutoGluonで再評価する場合は、[AutoGluonとのクロスチェック手順](experiments/autogluon_sl_crosscheck/README.md)を参照してください。

順位付け時に、選定モデルの統計区間と浮動小数点の丸めの点検も同じExcelに出力します。`--shift "FEATURE=OFFSET"` を指定すると、運用時の校正ずれを仮定した予測感度も計算します。保存済みの順位で別のずれを試す手順は[不確かさの点検手順](docs/SL_UNCERTAINTY_AUDIT.md)にあります。

## カルマンフィルタによる時系列の予測と推定

状態推定には専用の `kalman-track` を指定します。数値の時刻順に並ぶ1系列から、1ステップ先の予測と観測後の状態推定を計算します。観測誤差と過程ノイズを指定でき、観測が欠けた時刻も予測を続けます。フィルタの実装は、専用コマンドや対応するPython APIを指定したときに読み込みます。

レポートには、力学モデルのみ・直近観測・カルマンフィルタの比較と、予測区間に値が入った割合を記録します。真値を渡せる模擬データでは、観測ノイズを含む次の測定値と、背後にある状態を別々に採点できます。 [模擬軌道での実行手順と結果](docs/UNCERTAINTY_DESIGN.md#カルマンフィルタで数値の時系列を点検する)

`--pilot-rows` と `--min-rmse-gain` を指定すると、先頭区間で直近観測より改善した場合だけカルマンフィルタを続けます。`--compact-report` はExcelを集計表に絞り、行別の結果はNPZに保存します。 [判定の条件と処理時間](docs/UNCERTAINTY_DESIGN.md#先頭区間でフィルタを続けるか決める)

`ekf-benchmark` は、拡張カルマンフィルタを2つの小規模な非線形モデルで検証します。真値からの誤差、95%区間の被覆率、区間幅を保存するので、UKFや粒子フィルタを同じ系列で比較する際の基準にできます。 [理論例と実行手順](docs/UNCERTAINTY_DESIGN.md#拡張カルマンフィルタの理論ベンチマーク)

`ukf-benchmark` は、同じ系列でEKFとアンセンテッドカルマンフィルタ（UKF）を比較します。`Metrics` と `Timing` に誤差・被覆率・区間幅とフィルタの処理時間を保存します。 [EKFとUKFの比較手順](docs/UNCERTAINTY_DESIGN.md#アンセンテッドカルマンフィルタの理論比較)

`particle-benchmark` は、同じ系列にブートストラップ粒子フィルタを加えます。粒子数を変えて、予測誤差・分位点の区間・処理時間を比較できます。UCI Bike Sharingの日次データで次の日の観測値を予測する再現例もあります。 [粒子フィルタの検証手順](docs/UNCERTAINTY_DESIGN.md#粒子フィルタの理論比較とuci再現)

Pythonでは `diy_automl.kalman_track_csv` を使えます。力学モデルと観測モデルを指定する多変量の状態推定には、`extended_kalman_filter`、`unscented_kalman_filter`、`bootstrap_particle_filter` を同じパッケージから呼び出せます。 [ボイジャーを題材にした状態推定例](docs/UNCERTAINTY_DESIGN.md#ボイジャーを題材にした合成追跡データ)

## グラフニューラルネットワークによるノード分類

`gnn-compare` は、Cora形式の既知グラフで2層GCNとロジスティック回帰を比較します。学習・選定・保留のノードを共通にし、macro F1、学習時間、ノード別の予測を保存します。Pythonでは `diy_automl.classify_graph_nodes` を使えます。 [Coraの実行手順と比較結果](docs/GRAPH_CLASSIFICATION.md)

## Annealing check

`annealing-check` は固定した分類器で、CPUのSimulated Annealingと同予算のランダム探索を比較する任意の特徴量選択です。選定は学習側の共通層化5分割で行い、各手法で選んだ列と全列モデルを保留テストで比較します。Pythonからは `diy_automl.annealing_check_csv` を呼べます。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m diy_automl annealing-check --csv data/reference/iris.csv --target target --budget 8 --exhaustive --output runs/annealing-iris
.\.venv\Scripts\python.exe -X utf8 scripts/validate_annealing_check.py runs/annealing-iris
```

`report.xlsx` の `Selection` に探索スコア・学習回数・時間、`Selected_Features` に列名、`Test_Differences` に同じテスト行を再標本化した性能差の区間が入ります。探索履歴、誤差評価の読み方、IrisとWineの検証結果は[Annealing checkの記録](docs/ANNEALING_CHECK.md)にあります。

## 評価値の誤差評価（0.4.0a6）

```sh
.venv/bin/python -m diy_automl uncertainty --run runs/wine-select --output runs/wine-uncertainty
.venv/bin/python scripts/validate_uncertainty_run.py runs/wine-uncertainty
```

`report.xlsx`のMetric_UncertaintyにAccuracy・macro Precision/Recall/F1の点推定、bootstrap標準誤差、95%区間を、Class_Uncertaintyにクラス別結果を出します。Intervalsに図を埋め込み、全反復と再標本化indexも保存します。標準誤差はbootstrap指標の標本SDで、反復数の平方根では割りません。既定はクラス別件数固定の1,000反復・seed 43です。`--resampling ordinary`でクラス件数も動かせます。

`run`のSL/DL、行単位分割の`select`、`tune`、`repeat-dl`に対応し、モデルやseedの順序を保ちます。ULには既存の安定性評価を使用します。行の独立性・代表性は別途確認が必要です。詳細は[ガイド](docs/METRIC_UNCERTAINTY_GUIDE.md)、検証結果は[0.4.0a6の記録](docs/VALIDATION_METRIC_UNCERTAINTY.md)にまとめています。

## DLの学習seed反復（0.4.0a2）

固定した分割とtrain-only scalerを共有し、全学習seedの指標・履歴・予測・重みを保存する `repeat-dl`（schema 5）を追加しました。初期化とshuffleの感度を記述し、test最高のseedは選びません。

```sh
.venv/bin/python -m diy_automl repeat-dl --csv data/reference/wine.csv --target target --training-seeds 42 43 44 --output runs/wine-repeat-dl
.venv/bin/python scripts/validate_dl_repeat.py runs/wine-repeat-dl
```

詳細は `docs/DL_REPEAT_GUIDE.md`、今回の検証は `docs/VALIDATION_DL_REPEAT.md` を参照してください。初回再実装の検証記録は上書きせず保持しています。

## ULの部分抽出による安定性（0.4.0a3）

`subsample-ul`（schema 6）は80%の行を非復元抽出し、各部分集合だけで標準化と学習をやり直します。抽出seedとモデルseedを分離し、全データ参照とのARI、反復間の共通行だけのARI、元行index・scaler・全割当を保存します。少ない共通行や単一クラスタの比較は状態を明示して未採点とします。自動選定やSEM/CIはありません。

```sh
.venv/bin/python -m diy_automl subsample-ul --csv data/reference/wine.csv --target target --sample-seeds 42 43 44 --output runs/wine-subsample
.venv/bin/python scripts/validate_ul_subsample.py runs/wine-subsample
```

新入口の上限は2,000行・100特徴量・参照を含む2,000候補fitです。詳細は `docs/UL_SUBSAMPLE_GUIDE.md`、検証結果は `docs/VALIDATION_UL_SUBSAMPLE.md` を参照してください。旧run/repeat-ulの動作と上限は維持しています。

## SLの設定探索と紹介記事（0.4.0a4）

`tune`（schema 7）は既定で27設定を学習側の共通5foldで比較し、選定した1設定だけを再学習・test評価します。各foldのtrain-only scaler、同率時の候補順、条件付きbootstrapを使います。詳細は `docs/SL_TUNING_GUIDE.md`、検証結果は `docs/VALIDATION_SL_TUNING.md` に記載しています。

```sh
.venv/bin/python -m diy_automl tune --csv data/reference/wine.csv --target target --output runs/wine-tune
.venv/bin/python scripts/validate_tuning_run.py runs/wine-tune
```

TensorFlowを導入せずSL/ULを試す場合は、`requirements-core.lock.txt` を導入してから `pip install --no-deps -e .` を実行できます。DLを含む全テストは従来の `requirements-local.lock.txt` を使用してください。

Zenn用の紹介原稿は `articles/`、選定フロー図は `images/diy-automl/selection-flow.png` に保存しています。2026年11月12日に利用者から公開先の共有があり、以下のリンクからZenn掲載記事を読めます。Git原稿の `published: false` は変更しておらず、掲載版と編集中の原稿は区別します。操作と過去の確認範囲は `docs/ZENN_GUIDE.md` を参照してください。

誤差評価を共通の軸に、[親記事](https://zenn.dev/okamasaya/articles/diy-automl-evaluation-framework)、[ビジネス向けの平易な説明と3テーマの実験](https://zenn.dev/okamasaya/articles/diy-automl-business-three-experiments)、[DS向けの推定条件・数式・保存結果](https://zenn.dev/okamasaya/articles/diy-automl-ds-uncertainty)の3本に分けています。統計的な不確かさ、学習の変動、数値計算誤差、系統的な偏りを区別し、現在の実装範囲と今後の設計を明示しています。

## 図付きExcel（0.4.0a5）

保存済みのrun/select/tune/反復結果から、モデルを再学習せずに図付きExcelを作れます。元の数値Excelと学習manifestはそのまま残し、画像・描画入力・配置・版を別に記録します。

`report --charts detail` は、分類の `select`・`tune` に各foldのスコアを、`tune` に学習時間の図を追加します。図の量は `none`、`summary`、`detail` から選べます。 [図付きExcelガイド](docs/EXCEL_REPORT_GUIDE.md#図の量を選ぶ)

```sh
.venv/bin/python -m diy_automl report --run runs/wine-tune --output runs/wine-tune-illustrated
.venv/bin/python scripts/validate_excel_report.py runs/wine-tune-illustrated
```

利用者が開くファイルは `report_with_figures.xlsx` です。操作と表示方針は `docs/EXCEL_REPORT_GUIDE.md`、検証は `docs/VALIDATION_EXCEL_REPORT.md` にあります。DS向けNotebook/CLIと、将来のビジネス向けアプリ・子記事をどう分けるかは `docs/AUDIENCE_PLAN.md` に記録しています。親記事は0.4.0a5へ更新し、モデルの新しさと改善幅の関係を参考文献付きで追記しました。追加モデル・データの検証、特に計算負荷の高い実験は `docs/MODEL_VALIDATION_TODO.md` の後続作業です。

海外の企業・大学・ビジネススクールが公開する業務データの候補は `docs/BUSINESS_DATASETS.md` に整理しました。実データ・架空教材・利用条件と、現行AutoMLで必要な準備を区別した調査で、これらのデータで学習を実行した記録ではありません。

初見で親しみやすい2テーマと、分析を深掘りする1テーマの検討内容は `docs/BUSINESS_SAMPLE_CANDIDATES.md` にあります。ホテル予約・飲食クーポン・再購入を扱います。

その後、利用者の承認を受け、ホテル2,000行・カフェ券2,000行・再購入1,743顧客を既存SLでQuick & dirtyに実行しました。実測と一般的な見方の比較は `docs/BUSINESS_QUICK_RESULTS.md`、保存結果は `validation/business-quick-20261108/`、再実行は `experiments/business_quick_20261108/README.md` です。親記事に要約を追記し、ビジネス向けの実験解説下書きも追加しました。追加モデルや一般的なカテゴリ/欠損処理、画面アプリは追加していません。
