# 既存3データセットの検証結果（添付Excelから確認）

注意：以下は**添付された実測Excelを読み取った値**であり、新たな再学習を行った結果ではない。元Notebookでは分割前に全件標準化しており、厳密な未知データ評価値としては再検証が必要。

## 1. 検証対象とファイル

| Dataset | 件数 | 特徴量 | クラス数 | 現行レポート |
| --- | ---: | ---: | ---: | --- |
| Iris | 150 | 4 | 3 | `reports/iris_ML_Result.xlsx` |
| Wine | 178 | 13 | 3 | `reports/wine_ML_Result.xlsx` |
| Breast Cancer | 569 | 30 | 2 | `reports/breast_cancer_ML_Result.xlsx` |

## 2. SL（各Excelの`SL_Result`シートから確認）

| Dataset | 最良Accuracyモデル | Accuracy | 補足 |
| --- | --- | ---: | --- |
| Iris | SVM | 0.966667 | 他の4モデルは各0.933333 |
| Wine | Random Forest | 1.000000 | 単一splitの36件testでの値。一般化保証ではない |
| Breast Cancer | Logistic Regression **およびSVM（同率）** | 0.982456 | 同率首位。`idxmax()`は最初のLogistic Regressionのみ返す |

## 3. UL（`UL_Result`から直接計算した指標別最良行）

| Dataset | Silhouette最大（モデル、k、Silhouette、ARI） | ARI最大（モデル、k、ARI、Silhouette） |
| --- | --- | --- |
| Iris | GMM, k=2, 0.581750, 0.568116 | GMM, k=4, 0.7819, 0.2310 |
| Wine | GMM, k=3, 0.284859, 0.8975 | GMM, k=3, 0.8975, 0.284859 |
| Breast Cancer | Hierarchical(complete), k=2, 0.6607, **ARI=0.0048** | GMM, k=2, **ARI=0.7740**, Silhouette=0.3145 |

**重要な観察**：Breast CancerではSilhouette最大のモデルと正解ラベル一致度最大のモデルが大きく異なる。これは今回の多指標評価が必要な理由を説明する重要な例であり、「高Silhouette=正解ラベルをよく再現する」と解釈してはいけない。IrisでもSilhouette最良k=2とARI最良k=4は異なる。

各ExcelのUL結果は55行（GMM9行 + 階層4種×9行 + KMeans10行）。現行Notebookで最後のKMeans k=10が重複登録されるためで、本来は54行（全6モデル種×9行）を想定。

## 4. DL（`DL_Result`から確認）

| Dataset | Model | Layers | Test Accuracy |
| --- | --- | --- | ---: |
| Iris | MLP | 32-16-8 | 0.933333 |
| Wine | MLP | 32-16-8 | 1.000000 |
| Breast Cancer | MLP | 32-16-8 | 0.964912 |

現行DLは各データセットで単一設定のみ実験。TensorFlowの乱数シードを固定しておらず、同一条件の再学習でも完全一致は保証されない。

## 5. 何を「検証済み」と呼ぶか

- **確認済み**：3つのsklearnデータセットに対し、SL/UL/DLコードが最後まで実行され、同じ5シート名のExcelファイルが得られたこと。
- **未検証**：任意CSV、欠損値・非数値列、ラベルなしUL、回帰、スケール前処理のリーク解消後の精度再評価、CVによる不確かさ、画像埋込性能、実用上の推奨モデル判定の正当性。
- `load_diabetes()` の記述はNotebookにあるがコメントアウトされており、分類用の現行ワークフローでの動作検証はしていない。

現行の優劣は固定された1回の分割での実測比較。Wineの1.0なども想定可能だが、それだけで未知データに対する完全予測性能を主張してはいけない。
