# 機械学習評価フレームワーク Ver.2 引継ぎパッケージ

作成日：2026-11-07  
目的：新しいChatGPTスレッドへ、現行Notebook・検証データ・Excel実測結果・設計判断・今後の改修課題を引き継ぐ。

## 最初に読む順番

1. `docs/01_NEW_THREAD_INSTRUCTIONS.md`：新スレッドに貼る指示文。
2. `docs/02_PROJECT_STATUS_AND_DESIGN.md`：設計思想、現在のSTEP構成、使い方。
3. `docs/03_RESULTS_AND_VALIDATION.md`：3種類のデータセットで確認済みの結果。
4. `docs/04_ISSUES_AND_NEXT_STEPS.md`：既知の修正点とSTEP7拡張の要件。
5. `source/Comp_MLmodel_ver2.ipynb`：**変更していない現行ソース**。

## 同梱内容

```text
ML_Framework_Handoff_20261107/
├── docs/
│   ├── 00_README_START_HERE.md
│   ├── 01_NEW_THREAD_INSTRUCTIONS.md
│   ├── 02_PROJECT_STATUS_AND_DESIGN.md
│   ├── 03_RESULTS_AND_VALIDATION.md
│   └── 04_ISSUES_AND_NEXT_STEPS.md
├── source/
│   └── Comp_MLmodel_ver2.ipynb
├── datasets/
│   ├── iris.csv
│   ├── wine.csv
│   ├── breast_cancer.csv
│   └── dataset_metadata.json
├── reports/
│   ├── iris_ML_Result.xlsx
│   ├── wine_ML_Result.xlsx
│   └── breast_cancer_ML_Result.xlsx
├── archive/
│   ├── Summary_STEP6.xlsx
│   ├── Summary_STEP6(1).xlsx
│   └── Summary_STEP6(2).xlsx
├── requirements.txt
└── SHA256SUMS.txt
```

`archive/` は途中段階のSTEP6集計であり、**最新の検証結果の正本は `reports/`** とする。

## 再開に必要なもの

- このZIP一式を新スレッドに渡す。併せて `docs/01_NEW_THREAD_INSTRUCTIONS.md` の文章を貼る。
- ソースはJupyter Notebook、元の実行環境はGoogle Colab（Google Driveマウントあり）。
- 再実行時はSTEP1の `dataset` と `output_summary` を環境に合わせて変更する。
- ローカル環境ではGoogle Driveマウントセルを実行せず、出力先をローカルパスにする。
- 添付CSVは**元データ再現用の追加資料**。現行NotebookはCSV入力にまだ対応していない。

## 重要な注意

現行ソースは動作確認済みの**スナップショット**であり、分析手続きが完全に妥当だと認定された最終版ではない。特に学習・評価データ分割前の標準化と、KMeans評価行の重複登録は最優先確認事項。数値実測値も同じ理由で暫定ベースラインとして扱う。

元ソース・Excelの元データは本パッケージ作成時に変更していない。データセットCSVはPythonのscikit-learn組込みデータから新規に書き出したものである。
