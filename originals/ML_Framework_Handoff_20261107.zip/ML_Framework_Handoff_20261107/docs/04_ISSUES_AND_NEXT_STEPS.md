# 技術レビュー・引継ぎ後の改修バックログ

## A. 早期に修正すべき点（優先順）

**A1. データリークを解消**（最優先）。現在STEP2で `StandardScaler().fit_transform(X_raw)` を全データに適用した後でSL/DL train/test分割。SL/DLでは先にsplitを行い、学習部分のみでscalerをfitし、validation/testにはtransformのみを適用する。scikit-learn Pipelineを推奨。ULは全件クラスタ解析なので目的別に前処理を明示する。修正後は3データのExcelを再生成し、旧値と混同しない。

**A2. ULの重複を排除**。STEP4-3がKMeans全kを直接DF追加し、その直後の別セルが最後の `k`,`labels`,`elapsed` を再度 `evaluate_clustering()` へ渡して追加。全件を統一関数で評価するループに変更し、重複セルを撤去。期待行数54（6モデル種×9k）。Notebookセル再実行時にDF初期化・追加重複が起きないようにする。

**A3. 乱数・評価手順を記録**。SLの単一test splitだけでは精度不確かさを十分示せない。StratifiedKFold/RepeatedStratifiedKFoldなどのCV結果、mean/SD/CI等の算出方針を決める。テストセットをチューニングに流用しない。DLでは `tf.keras.utils.set_random_seed(...)` などとvalidationのstratificationを検討し、history・best epoch・early stopping設定を記録。

**A4. UL評価の意味を厳密化**。`silhouette_samples()`の点ごとのSDは「各サンプルのクラスタへの適合度の散らばり」であり、再実行安定性ではない。`scipy.stats.sem`は点ごとの標準誤差の計算だがSilhouette値は互いに独立ではなく、単純な平均の信頼区間とは解釈できない。再現性は独立seed・データ再標本化・クラスタ一致評価などを別途設計。ARI/AMI/NMIはラベルがある場合だけ「外部検証」に使用。内部選定指標と外部検証指標を分離する。

**A5. 選定ルール・推奨コメントを誤解なく設計**。例えばIrisのSilhouette最大k=2とARI最大k=4、Breast CancerでSilhouette最大とARI最大が違う。単純な1本の加重スコア化やAccuracy vs Silhouetteの数値比較はしない。SL/DL同率処理やクラス不均衡への対応も必要。

**A6. 汎用CSV化の境界条件**。STEP1の `X_raw/y` 固定Bunch読込を読み込み関数へ。target列名、欠損、非数値、クラスID符号化、未知カテゴリ、正解ラベルなしUL、回帰問題の扱いなど、サポート範囲を先に決める。現状の `load_diabetes` は回帰データであり対象外。Colab専用Driveパスは設定化する。

## B. 次スレッドで最初に進めるSTEP7拡張（ユーザー合意済み方向）

**目的**：Notebookには各モデル・候補の評価図を表示可能にし、Excelには重要な結果のうち**各手法で上位最大3件**の代表的な図だけを埋め込む。現行の5シート構成を維持するのが初期案。Excelを画像倉庫にしない。

### B1. 図の候補

| 対象 | Notebookでの図 | Excelに入れる図（最大3候補） |
| --- | --- | --- |
| SL | モデル別Confusion Matrix、必要に応じROC/PR | 選定上位3モデルのConfusion Matrix |
| UL | クラスタ数別のSilhouette、CH、DB（共通x軸・縦並び）、PCA 2Dクラスタ散布図、必要ならSilhouette plot | 内部指標による上位候補のPCA+クラスタ評価。外部ARI最良は参考として別枠または注記 |
| DL | Accuracy/Loss対Epoch、Confusion Matrix | 現状単一MLPの学習曲線（2指標）とConfusion Matrix。複数config実装後は最大3設定を比較 |

### B2. 選定ロジック

- SLは評価基準を明示（例：macro F1、同点時Accuracy、その後学習時間）。臨床上の重要クラスがあるタスクはRecallやPR-AUCを優先する可能性あり。
- ULは内部評価の最適kとARI/AMI/NMIなどの正解ラベル比較を区別する。クラスタ数を`y`から自動的に決めない。
- DLは現状モデル1件。常に3つの図・3設定を無理に作らない。`DL_config` と実際に使った上書き後設定を記録する。

### B3. 実装方法・負荷試験

1. グラフの生成関数をSTEP7から呼ぶ形で共通化。`fig`を返して描画と保存を分離する。
2. Notebook側は全候補を確認可能にするが、描画が重い場合は `plot_all=True/False` の切り替えを準備する。Silhouetteの全行列距離計算は件数が増えると負荷が大きいため注意。
3. Excel側は上位最大3候補の図をPNG（目安DPI=120〜150）として生成し、openpyxlなどで各既存シートの表と重ならない位置に埋め込む。画像は一時バッファ/個別PNGのどちらも可。外部保存する場合は実験名ごとにフォルダ管理。
4. Wine、Iris、Breast Cancerの順に、生成時間・Excelサイズ・表示レイアウト・数値/図の対応を確認する。旧レポートは残す。
5. 既存 `to_excel` の列見出し・数値・5シート名を壊さない。Excel Summaryの自動コメントは別タスク。

### B4. 完了条件（例）

- `result_df_SL/UL/DL` と `history_df_DL` が数値として従来どおり保存される。
- 上位の選定理由（使用指標・タイブレーク）をExcelに書く。
- Excelの画像がデータ表を覆わず、画像のモデル名・データセット・k/configを特定できる。
- PNGの追加数が制御可能で、3データセットで実行・閲覧可能。
- 元Notebookおよび既存Excelのスナップショットは保持する。

## C. その後の開発

- STEP6/7：Summaryシートを「Bestモデル名、評価スコア、評価の方向、条件、検証状況、解釈・注意」へ拡張。既存の `best_model_report` は計算するだけで未出力。
- 評価の信頼性：交差検証・標準偏差・Confidence Interval・学習曲線・クラスタ安定性を段階的に導入。
- CSV入力：DataLoader、前処理、分類/クラスタのtask routing、再利用可能な設定辞書化。
- `.py`分離・パッケージ構成、データセット別の結果再現テスト、依存バージョン記録、Gitに残す開発ログ。
